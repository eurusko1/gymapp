﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Gymapp1.Migrations
{
    public partial class times0 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
