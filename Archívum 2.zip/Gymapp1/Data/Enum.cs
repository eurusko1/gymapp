﻿using System;
namespace Gymapp1.Data
{
    public enum OperationType
    {
        None = 0,
        Insert = 1,
        Update = 2,
        Delete = 3
    }
}
