﻿using System;
namespace Gymapp1.Data
{
    public enum Gender
    {
        Male,
        Female,
        Other
    }
}
