﻿using System;
namespace Gymapp1.Models
{
    public class TimeModel
    {
        public int Id { get; set; }

        public string IdoPont { get; set; }

        public string SelectedTime { get; set; }

        public string Bookings { get; set; }
    }
}
