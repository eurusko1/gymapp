﻿using System;
using System.Collections.Generic;

namespace Gymapp1.Data
{
    public class WeekClass
    {
        public List<DayEvent> Dates { get; set; } = new List<DayEvent>();

    }
}
